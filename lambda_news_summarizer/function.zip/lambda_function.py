import json
import requests

def lambda_handler(event, context):
    try:
        # Parse input URL from POST request
        body = json.loads(event.get('body', '{}'))
        news_url = body.get('url')
        
        if not news_url:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'No URL provided'})
            }
        
        # Call a free summarizer API (SMMRY example)
        API_KEY = 'sk-smmry-a827de34adad2ca49121866138e0f588584b217b1963bc4471a7801423f2a8f5'  # You can get a free key from smmry.com
        api_url = f'https://api.smmry.com?SM_API_KEY={API_KEY}&SM_URL={news_url}'
        
        response = requests.get(api_url)
        data = response.json()
        
        summary = data.get('sm_api_content', 'Could not summarize the article')
        
        return {
            'statusCode': 200,
            'body': json.dumps({'summary': summary})
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
